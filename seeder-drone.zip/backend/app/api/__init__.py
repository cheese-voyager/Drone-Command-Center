"""Endpoint HTTP dan WebSocket."""
